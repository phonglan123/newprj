import random, os

os.system('cls')
print('=================')
print('|  BẠN  |  MÁY  |')
print('|       |       |')
print('|   ?   |   ?   |')
print('=================')
print('Bạn đã ???\n')

def getUserResult(computerValue, userValue):
	if computerValue == userValue:
		return 'hoà'
	elif (computerValue == 'kéo' and userValue == 'búa') or (computerValue == 'búa' and userValue == 'bao') or (computerValue == 'bao' and userValue == 'kéo'):
		return 'thắng'
	else:
		return 'thua'

while True:
	userInput = input('Nhập giá trị (kéo/búa/bao/thoát): ')
	os.system('cls')
	if userInput == 'thoát':
		break
	values = ['kéo', 'búa', 'bao']
	computerInput = int(random.random() * 3)
	computerValue = values[computerInput]
	userValue = userInput
	print('=================')
	print('|  BẠN  |  MÁY  |')
	print('|       |       |')
	print('|  ' + userInput.title() + '  |  ' + values[computerInput].title() + '  |')
	print('=================')
	print('Bạn đã ' + getUserResult(computerValue, userValue) + '\n')

print('Trò chơi kết thúc!')