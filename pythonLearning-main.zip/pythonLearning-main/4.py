tencacloaihoa=['hong','lan','cuc']
tencacloaihoa[0]=input("hãy viết loài hoa bạn thích nhất")
print(tencacloaihoa)