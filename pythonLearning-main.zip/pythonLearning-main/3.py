import os
import random

class Race:
	def __init__(self, raceList):
		self.race = raceList
		self.maxRow = len(self.race[0]) - 1

	# pointerLoc [start]
	
	def getPointerLoc(self):
		for yIndex, yVal in enumerate(self.race):
			for xIndex, xVal in enumerate(yVal):
				if xVal == 2:
					return {'y': yIndex, 'x': xIndex}
	
	def setPointerLoc(self, newLoc):
		oldLoc = self.pointerLoc
		self.race[oldLoc['y']][oldLoc['x']] = 0
		self.race[newLoc['y']][newLoc['x']] = 2

	pointerLoc = property(getPointerLoc, setPointerLoc) 

	# pointerLoc [end]

	# move direction [start]

	def goUp(self):
		newLoc = {'y': self.pointerLoc['y'] - 1, 'x': self.pointerLoc['x']}
		if self.pointerLoc['y'] == 0:
			return 'win'
		if self.race[newLoc['y']][newLoc['x']] == 1:
			return False
		self.pointerLoc = newLoc
		return True

	def goLeftCorner(self):
		newLoc = {'y': self.pointerLoc['y'] - 1, 'x': self.pointerLoc['x'] - 1}
		if self.pointerLoc['y'] == 0:
			return 'win'
		if self.pointerLoc['x'] == 0:
			return False
		if self.race[newLoc['y']][newLoc['x']] == 1:
			return False
		self.pointerLoc = newLoc
		return True

	def goRightCorner(self):
		newLoc = {'y': self.pointerLoc['y'] - 1, 'x': self.pointerLoc['x'] + 1}
		if self.pointerLoc['y'] == 0:
			return 'win'
		if self.pointerLoc['x'] == self.maxRow:
			return False
		if self.race[newLoc['y']][newLoc['x']] == 1:
			return False
		self.pointerLoc = newLoc
		return True

	def turnRight(self):
		newLoc = {'y': self.pointerLoc['y'], 'x': self.pointerLoc['x'] + 1}
		if self.pointerLoc['x'] == self.maxRow:
			return False
		if self.race[newLoc['y']][newLoc['x']] == 1:
			return False
		self.pointerLoc = newLoc
		return True

	def turnLeft(self):
		newLoc = {'y': self.pointerLoc['y'], 'x': self.pointerLoc['x'] - 1}
		if self.pointerLoc['x'] == 0:
			return False
		if self.race[newLoc['y']][newLoc['x']] == 1:
			return False
		self.pointerLoc = newLoc
		return True

	# move direction [end]

	def multipleMoves(self, moves, changeCallback):
		changeCallback(self.race)
		moveMethod = None
		for move in moves:
			if move == 'U':
				moveMethod = 'goUp'
			elif move == 'R':
				moveMethod = 'turnRight'
			elif move == 'L':
				moveMethod = 'turnLeft'
			elif move == 'W':
				moveMethod = 'goRightCorner'
			elif move == 'M':
				moveMethod = 'goLeftCorner'

			moveReturn = getattr(self, moveMethod)()
			if not moveReturn:
				return False
			if moveReturn == 'win':
				return 'win'
			changeCallback(self.race)
		return True

class RaceAutoPlay:
	def __init__(self, getRaceFunc, winningMoveCb):
		self.getRaceFunc = getRaceFunc
		self.winningMove = []
		self.tryMove('')
		winningMoveCb(self.winningMove)

	def tryMove(self, move):
		for newMove in ['U', 'W', 'M']:
			if (move + newMove):
				currentMove = Race(self.getRaceFunc()).multipleMoves(move + newMove, self.noWriteChange)
				if currentMove == 'win':
					self.winningMove.append(move + newMove)
				elif currentMove:
					self.tryMove(move + newMove)

	def noWriteChange(self, change):
		pass

class AutoPlayUI:
	def __init__(self, getRaceFunc, inputPause):
		self.getRaceFunc = getRaceFunc
		self.inputPause = inputPause
		os.system('cls')
		print('...')
		RaceAutoPlay(self.getRaceFunc, self.winningMoveCb)

	def writeChange(self, change):
		os.system('cls')
		for row in change:
			thisRow = ''
			for item in row:
				if item == 0:
					thisRow += '  '
				elif item == 1:
					thisRow += '##'
				else:
					thisRow += 'OO'
			print('|' + thisRow + '|')
		if self.inputPause:
			input('')

	def winningMoveCb(self, winningMove):
		os.system('cls')
		print(winningMove)
		Race(self.getRaceFunc()).multipleMoves(random.sample(winningMove, 1)[0], self.writeChange)

# Only change below

AutoPlayUI(lambda: [
	[1, 0, 1, 1, 1, 1, 1],
	[0, 1, 1, 0, 1, 0, 1],
	[0, 0, 1, 0, 1, 0, 0],
	[0, 1, 1, 0, 0, 1, 0],
	[0, 1, 1, 0, 1, 0, 0],
	[0, 1, 0, 1, 0, 0, 0],
	[0, 1, 1, 0, 1, 0, 0],
	[1, 0, 1, 0, 0, 1, 1],
	[0, 0, 1, 0, 1, 0, 0],
	[0, 0, 1, 1, 0, 1, 0],
	[0, 0, 0, 0, 0, 1, 0],
	[0, 1, 1, 1, 1, 0, 0],
	[1, 0, 1, 1, 0, 1, 1],
	[1, 1, 0, 1, 1, 1, 1],
	[1, 1, 1, 0, 0, 1, 1],
	[1, 1, 0, 1, 1, 0, 1],
	[1, 0, 1, 1, 1, 1, 0],
	[0, 1, 1, 1, 1, 0, 0],
	[1, 1, 1, 1, 1, 0, 2]
], True)