'''
AVAILABLE:

RomanToArabic(romanNumber)
ArabicToRoman(arabicNumber)
Root(n, x) [nth root of x]


UNAVAILABLE:
Log()
'''

class Ext:
	def getKeyByVal(dict, val):
		for key, value in dict.items():
			if val == value:
				return key
		return False

romanValue = {'IV': 4, 'IX': 9, 'XL': 40, 'XC': 90, 'CD': 400, 'CM': 900, 'M': 1000, 'D': 500, 'C': 100, 'L': 50, 'X': 10, 'V': 5, 'I': 1}

def RomanToArabic(romanNumber):
	arabicNumber = 0
	for key, value in romanValue.items():
		arabicNumber += value * romanNumber.count(key)
		romanNumber = romanNumber.replace(key, '')
	return arabicNumber

def ArabicToRoman(arabicNumber):
	stringNum = str(arabicNumber).rjust(4, '0')
	fourthPosZeros = '0' * (len(stringNum) - 1)
	positions = [int(stringNum[-1]), int(stringNum[-2] + '0'), int(stringNum[-3] + '00'), int(stringNum[0:-3] + fourthPosZeros)]
	romanNumber = ''

	for i in range(4):
		if positions[i] != 0:
			if Ext.getKeyByVal(romanValue, positions[i]) != False:
				romanNumber = Ext.getKeyByVal(romanValue, positions[i]) + romanNumber
			else:
				positionValue = positions[i] / int(10 ** i)
				positionLetter = Ext.getKeyByVal(romanValue, 10 ** i)
				romanNumber = positionLetter * int(positionValue) + romanNumber

	return romanNumber

def Root(n, x) #nth root of x
	return x**(1/float(n))

def Log():
	pass

