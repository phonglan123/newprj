str1, str2 = "Phong", "Nguyễn Hải"
print((str1 + str2) * (2 ** 2));
print("Phong" in "Nguyễn Hải Phong")
s = 'abc xyz'
print(s[None:4])  # lấy các kí tự có vị trí từ 0 đến 3
print(s[:-1])  # ta cũng có thể để trống, Python sẽ tự hiểu là None
print(s[:])  # một cách sao chép chuỗi
print(s[1:7:2]) #  bước là 2

'''
string.capitalize() viết hoa chữ cái đầu câu
string.title()      viết hoa chữ cái đầu từ
string.lower() và upper()
string.swapcase() chuyển hoa -> thường, thường -> hoa
string.replace(old, new, [count])
'''

print('  Kter   '.strip()) # 'Kter'
print('%%%%Kter%%%'.strip('%')) # 'Kter'
print('cababHowbaaaca'.strip('abc')) # 'How'

# string.split(kí tự ngăn cách, maxsplit=-1)

# string.count(sub, [start, [end]]) : đếm số lần xuất hiện của sub
# string.startswith(prefix[, start[, end]]) và tương tự cho endswith
# string.find(sub[, start[, end]]) bằng với hàm indexOf trong JS

'''
>>> 'a' in [['a'], 'b', 'c'] # chỉ có ['a'] thôi, không có 'a'
False
'''

test1 = [1, 2, 3]
test1.append([4, 5])
print(test1) # [1, 2, 3, [4, 5]]
test1.extend([4, 5])
print(test1) # [1, 2, 3, [4, 5], 4, 5]

#list.insert (i, x) - Thêm phần x vào vị trí i ở trong List.
#list.remove(x) - Bỏ phần tử ở vị trí x

'''
Xử lí list
reverse(): đảo ngc
sort(): xếp theo thứ tự tăng dần - giảm dần (cái này sẽ nói sau)
'''

a, b = int(input('Enter the first number: ')), int(input('Enter the second number: '))
if a - b == 0:
	print('a = b')
elif a - b > 0:
	print('a > b')
else:
	print('a < b')

for k in (1, 2, 3):
	print(k)
else:
	print('Done!')