from sklearn import tree

input = [[0], [5], [6], [7], [8], [2], [9], [10], [9.5], [10], [2], [4], [8.9]]
output = [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0]

decisionTree = tree.DecisionTreeClassifier()
result = decisionTree.fit(input, output)
myResult = result.predict([[9.01], [8], [8.923], [1], [7], [11]])

print(myResult)
