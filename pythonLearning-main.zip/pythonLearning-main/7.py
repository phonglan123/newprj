# Setter, getter, deleter (dùng một class riêng để thực hiện việc gán get và set)

class SimpleProperty(object):
  def __init__(self,fget,fset):
    self.fget = fget
    self.fset = fset
  def __get__(self,instance,cls):
    return self.fget(instance)    # Calls instance.fget()
  def __set__(self,instance,value)
    return self.fset(instance,value) # Calls instance.fset(value)


class Circle(object):
   def __init__(self,radius):
     self.radius = radius
   def getArea(self):
     return math.pi*self.radius**2
   def setArea(self):
     self.radius = math.sqrt(area/math.pi)
   area = SimpleProperty(getArea,setArea)
  
c = Circle(10)
a = c.area       # Implicitly calls c.getArea()
c.area = 10.0    # Implicitly calls c.setArea(10.0)

# ---- ---- ---- ----

# Special methods
class Vector(object):
    def __init__(self, *args):
        """ Create a vector, example: v = Vector(1,2) """
        if len(args) == 0:
             self.values = (0,0)
        else:
             self.values = args

    def __add__(self, other):
        """ Returns the vector addition of self and other """
        added = tuple(a + b for a, b in zip(self.values, other.values) )
        return Vector(*added)

v1 = Vector(1, 2)
v2 = Vector(10, 13)
v3 = v1 + v2
print(v3.values) # Will return (11, 15)

# Read more here: https://www.informit.com/articles/article.aspx?p=453682&seqNum=6
