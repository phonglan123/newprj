'''
Bài 1 (5đ):
Cho user nhập vào thông tin với công thức: "<a>-<b>"
<a>: Họ Tên (bắt buộc họ Nguyễn)
<b>: Quốc tịch (không được quá 2 người trùng nhau)
GỢI Ý: Dùng Dict, split()

Bài 2 (1đ):
Cho người dùng nhập họ mới của thành viên đó

Bài 3 (4đ):
Đếm số từ và kí tự (GỢI Ý: count())
'''

userInput = input("Nhập vào họ và tên và quốc tịch: ")
info = {
    'firstName': '',
    'lastName': '',
    'national': ''
}

info['firstName'] = userInput.split('-')[0]
info['lastName'] = userInput.split('-')[1]
info['national'] = userInput.split('-')[2]

print(info)

info['lastName'] = input("Nhập họ mới: ")

print(info)

fullName = info['lastName'] + " " + info['firstName'] 

print("Kí tự: " + str(len(fullName)))
print("Số từ: " + str(len(fullName.split(' '))))
